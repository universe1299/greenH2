
% load data

load initData

%set irradiance

%irradiance = StationData(1).Irradiance;

irradiance = xlsread("IRD3year.xlsx")   